class LogMixin:
    def log(self, mensaje):
        print(f"[{self.__class__.__name__}] {mensaje}")

class InventarioMixin:
    def __init__(self):
        self.inventario = []

    def agregar_item(self, item):
        self.inventario.append(item)
        print(f"{item} agregado al inventario.")

    def usar_item(self, item):
        if item in self.inventario:
            self.inventario.remove(item)
            print(f"{item} usado.")
        else:
            print(f"{item} no está en el inventario.")

    def listar_inventario(self):
        print("Inventario:", self.inventario)
