import random
from clases.clases_concretas import Guerrero, Mago, Arquero, Sanador

# Lista global de personajes creados
personajes = []

def crear_personaje():
    try:
        tipo = input("Tipo de personaje (Guerrero/Mago/Arquero/Sanador): ").strip().lower()
        nombre = input("Nombre del personaje: ").strip()
        salud = int(input("Salud máxima: "))
        ataque = int(input("Ataque base: "))
        defensa = int(input("Defensa base: "))

        if salud <= 0 or ataque <= 0 or defensa <= 0:
            print("❌ Las estadísticas deben ser positivas.")
            return

        if tipo == "guerrero":
            personaje = Guerrero(nombre, salud, ataque, defensa)
        elif tipo == "mago":
            personaje = Mago(nombre, salud, ataque, defensa)
        elif tipo == "arquero":
            personaje = Arquero(nombre, salud, ataque, defensa)
        elif tipo == "sanador":
            personaje = Sanador(nombre, salud, ataque, defensa)
        else:
            print("❌ Tipo de personaje no válido.")
            return

        personajes.append(personaje)
        print(f"✅ Personaje {nombre} creado exitosamente.")

    except ValueError:
        print("❌ Error: ingresa valores numéricos válidos.")

def ver_personajes():
    if not personajes:
        print("No hay personajes creados.")
    else:
        for p in personajes:
            p.mostrar_info()

def simular_batalla():
    if len(personajes) < 2:
        print("❌ Se necesitan al menos 2 personajes para la batalla.")
        return

    try:
        n_equipo = int(input("¿Cuántos personajes por equipo?: "))
        if n_equipo <= 0:
            print("❌ El número debe ser positivo.")
            return

        equipo1 = random.sample(personajes, min(n_equipo, len(personajes)))
        equipo2 = random.sample(personajes, min(n_equipo, len(personajes)))

        print("\n⚔️ ¡Comienza la batalla! ⚔️")
        turno = 1
        while any(p.esta_vivo() for p in equipo1) and any(p.esta_vivo() for p in equipo2):
            print(f"\n--- TURNO {turno} ---")
            for p in equipo1:
                if p.esta_vivo():
                    objetivo = random.choice([e for e in equipo2 if e.esta_vivo()])
                    p.atacar(objetivo)
            for p in equipo2:
                if p.esta_vivo():
                    objetivo = random.choice([e for e in equipo1 if e.esta_vivo()])
                    p.atacar(objetivo)
            turno += 1

        if any(p.esta_vivo() for p in equipo1):
            print("\n🏆 ¡Equipo 1 gana!")
        else:
            print("\n🏆 ¡Equipo 2 gana!")

    except ValueError:
        print("❌ Ingresa un número válido.")

def ver_estadisticas():
    conteo = {"Guerrero":0, "Mago":0, "Arquero":0, "Sanador":0}
    for p in personajes:
        conteo[p.obtener_clase()] += 1
    print("\n📊 Estadísticas de personajes:")
    for tipo, cantidad in conteo.items():
        print(f"{tipo}: {cantidad}")

def menu():
    while True:
        print("\n===== MENÚ PRINCIPAL =====")
        print("1. Crear personaje")
        print("2. Ver personajes")
        print("3. Simular batalla")
        print("4. Ver estadísticas")
        print("5. Salir")

        opcion = input("Elige una opción: ").strip()
        if opcion == "1":
            crear_personaje()
        elif opcion == "2":
            ver_personajes()
        elif opcion == "3":
            simular_batalla()
        elif opcion == "4":
            ver_estadisticas()
        elif opcion == "5":
            print("👋 Saliendo del programa...")
            break
        else:
            print("❌ Opción no válida.")

if __name__ == "__main__":
    menu()

