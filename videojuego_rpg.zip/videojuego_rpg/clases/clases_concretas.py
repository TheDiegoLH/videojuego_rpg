from clases.personaje import Personaje
from clases.interfaces import IAtacante, IDefensor, ICurable, IHabilidadEspecial
from clases.mixins import LogMixin, InventarioMixin

class Guerrero(Personaje, IAtacante, IDefensor, IHabilidadEspecial, LogMixin, InventarioMixin):
    def atacar(self, objetivo):
        dano = int(self.ataque_base * 1.5)
        objetivo.recibir_dano(dano)
        self.log(f"{self.nombre} ataca con fuerza causando {dano} de daño.")

    def usar_habilidad_especial(self):
        print(f"{self.nombre} usa 'Golpe aplastante' causando daño doble.")
    
    def obtener_clase(self):
        return "Guerrero"

    def obtener_defensa_total(self):
        return self.defensa_base

    def obtener_costo_habilidad(self):
        return 15


class Mago(Personaje, IAtacante, ICurable, IHabilidadEspecial, LogMixin, InventarioMixin):
    def atacar(self, objetivo):
        dano = int(self.ataque_base * 2.0)
        objetivo.recibir_dano(dano)
        self.log(f"{self.nombre} lanza un hechizo causando {dano} de daño.")

    def curar_aliado(self, aliado, cantidad):
        aliado.curar(cantidad)
        self.log(f"{self.nombre} cura a {aliado.nombre} con {cantidad} puntos.")

    def revivir(self, aliado):
        if not aliado.esta_vivo():
            aliado.salud = aliado.salud_maxima // 2
            self.log(f"{self.nombre} revive a {aliado.nombre} con {aliado.salud} de salud.")

    def usar_habilidad_especial(self):
        print(f"{self.nombre} lanza 'Bola de fuego' causando daño en área.")

    def obtener_clase(self):
        return "Mago"

    def obtener_costo_habilidad(self):
        return 20


class Arquero(Personaje, IAtacante, IHabilidadEspecial, LogMixin, InventarioMixin):
    def atacar(self, objetivo):
        dano = int(self.ataque_base * 1.2)
        objetivo.recibir_dano(dano)
        self.log(f"{self.nombre} dispara una flecha causando {dano} de daño.")

    def usar_habilidad_especial(self):
        print(f"{self.nombre} usa 'Flecha certera' con probabilidad de crítico.")

    def obtener_clase(self):
        return "Arquero"

    def obtener_costo_habilidad(self):
        return 10


class Sanador(Personaje, ICurable, IDefensor, IHabilidadEspecial, LogMixin, InventarioMixin):
    def curar_aliado(self, aliado, cantidad):
        aliado.curar(cantidad)
        self.log(f"{self.nombre} cura a {aliado.nombre} con {cantidad} puntos.")

    def revivir(self, aliado):
        if not aliado.esta_vivo():
            aliado.salud = aliado.salud_maxima // 2
            self.log(f"{self.nombre} revive a {aliado.nombre} con {aliado.salud} de salud.")

    def defender(self):
        super().defender()

    def usar_habilidad_especial(self):
        print(f"{self.nombre} usa 'Bendición' y cura a todos los aliados.")

    def obtener_clase(self):
        return "Sanador"

    def obtener_defensa_total(self):
        return self.defensa_base

    def obtener_costo_habilidad(self):
        return 12

