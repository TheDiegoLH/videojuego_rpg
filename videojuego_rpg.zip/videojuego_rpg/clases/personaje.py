from abc import ABC, abstractmethod

class Personaje(ABC):
    def __init__(self, nombre, salud_maxima, ataque_base, defensa_base):
        if salud_maxima <= 0 or ataque_base <= 0 or defensa_base <= 0:
            raise ValueError("Las estadísticas deben ser positivas.")
        self.nombre = nombre
        self.nivel = 1
        self.salud_maxima = salud_maxima
        self.salud = salud_maxima
        self.ataque_base = ataque_base
        self.defensa_base = defensa_base
        self._defendiendo = False

    @abstractmethod
    def atacar(self, objetivo):
        pass

    @abstractmethod
    def usar_habilidad_especial(self):
        pass

    @abstractmethod
    def obtener_clase(self):
        pass

    def recibir_dano(self, cantidad):
        if self._defendiendo:
            cantidad //= 2
        self.salud -= cantidad
        if self.salud < 0:
            self.salud = 0
        print(f"{self.nombre} recibe {cantidad} de daño. Salud actual: {self.salud}")

    def defender(self):
        self._defendiendo = True
        print(f"{self.nombre} se pone en modo defensa.")

    def curar(self, cantidad):
        self.salud = min(self.salud + cantidad, self.salud_maxima)
        print(f"{self.nombre} se cura {cantidad}. Salud actual: {self.salud}")

    def subir_nivel(self):
        self.nivel += 1
        self.salud_maxima += 10
        self.ataque_base += 2
        self.defensa_base += 2
        print(f"{self.nombre} sube a nivel {self.nivel}.")

    def esta_vivo(self):
        return self.salud > 0

    def mostrar_info(self):
        print(f"{self.nombre} ({self.obtener_clase()}) - Nivel {self.nivel}, Salud {self.salud}/{self.salud_maxima}")

    def __str__(self):
        return f"{self.nombre} ({self.obtener_clase()})"
